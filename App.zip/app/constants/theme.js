const theme = 
{
    colors:
    {
        primary: "#000000",
        secondary: "#FFFFFF",
        tertiary: "#B9B9BE",
        gray: "#F7F5F5",
        yellow: "#FABB18"
    }
}

export {theme}